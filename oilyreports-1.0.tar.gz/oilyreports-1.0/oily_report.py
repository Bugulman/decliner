import pandas as pd
import pprint
import os
import datetime
import getpass
import urllib
import sqlalchemy

def dataframe_creater(*args, start='01.01.2000', **kwarg):
    """Function for converting navigation format to pandas dataframe
         *args - list of arguments to issue in the frame 
             dimens - well, here is one of two:
			well - for issuing a frame for wells
			group - for issuing by group"""
    indicators = [x for x in args]
    name = ['Parametr{}'.format(x) for x in range(0, len(indicators))]
    indicators_dict = dict.fromkeys(['date', 'well']+name)
    indicators_dict = {x:[] for x in indicators_dict.keys()} 
    assos_dict = {x:y for x,y in zip(indicators, name)}
    start_date = datetime.datetime.strptime(start, '%d.%m.%Y')
    for m in kwarg['mod']:
        for w in kwarg['wells']:
            for t in kwarg['step']:
                if t.to_datetime() >= start_date:
                    indicators_dict['date'].append(t.to_datetime())
                    indicators_dict['well'].append(w.name)
                    for i in indicators:
                        indicators_dict[assos_dict[i]].append(i[m,w,t].to_list()[0])
                else:
                    continue
    result = pd.DataFrame(indicators_dict, index = indicators_dict['date'])
    return result.drop('date', axis=1)
     

def adapt_report_frame(frame, **kwarg):
    frame.columns=['well', 'wlpt', 'wlpth', 'wopt', 'wopth']
    well_cum = frame.loc[frame.index == frame.index.max()]
    well_cum['lik_diff'] = (well_cum['wlpth']-well_cum['wlpt'])/well_cum['wlpth']*100
    well_cum['oil_diff'] = (well_cum['wopth']-well_cum['wopt'])/well_cum['wopth']*100
    well_cum['oil'] = pd.cut(well_cum['oil_diff'], [-1000, -20, 20.5, 1000], labels=['to_mach', 'good', 'poor'])
    well_cum['lik'] = pd.cut(well_cum['lik_diff'], [-1000, -20, 20.5, 1000], labels=['to_mach', 'good', 'poor'])
    final={}
    final['user'] = getpass.getuser()
    final['model'] = [i.name for i in kwarg['mod']][0]
    final['date'] = datetime.datetime.now()
    final['total_wells'] = well_cum.loc[well_cum['wopth']>0, 'well'].unique().shape[0]    
    final['total_oil'] = well_cum['wopt'].sum()/well_cum['wopth'].sum()*100
    final['total_liq'] = well_cum['wlpt'].sum()/well_cum['wlpth'].sum()*100
    final['oil_adapt'] = well_cum.loc[well_cum['oil']=='good', 'wopth'].sum()/well_cum['wopth'].sum()*100
    final['liq_adapt'] = well_cum['lik'].value_counts(normalize=True)[1]*100
    final['wells_adapt'] = well_cum['oil'].value_counts(normalize=True)[1]*100
    return pd.DataFrame(final, index=[1])


def create_report_dir(path):
    '''Creates a result folder and sets it by default when writing files
        path = r let to the model's sensor'''
    if os.path.exists((path+r'\\reports')):
        os.chdir(path+r'\\reports')
    else:
        os.chdir(path)
        os.mkdir('reports')
        os.chdir(path+r'\\reports')
        

