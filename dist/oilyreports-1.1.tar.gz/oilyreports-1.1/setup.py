from setuptools import setup

setup(
    name="oilyreports",
    version="1.1",
    description="tNavigator additional module",
    autor="VafinAR",
    autor_email="reg16vp@mail.ru",
    py_modules=["oily_report"],
)
